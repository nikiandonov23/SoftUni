﻿using System.IO;
using System.Linq;

namespace EvenLines
{
    using System;
    public class EvenLines
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";

            Console.WriteLine(ProcessLines(inputFilePath));
        }

        public static string ProcessLines(string inputFilePath)
        {
            string[] allLines = File.ReadAllLines(inputFilePath);

            string final = "";
            for (int i = 0; i < allLines.Length; i+=2)
            {
                final += CleanedText(allLines[i]);
            }
            return final;
        }

        private const string CharacterToReplace = "-,.!?";
        private static string CleanedText(string text)
        {
            foreach (var character in CharacterToReplace)
            {
                text = text.Replace(character, '@');
                
            }
            string[] words = text.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Array.Reverse(words);
            string textToReturn = string.Join(" ", words);

            return textToReturn;
        }
    }
}
