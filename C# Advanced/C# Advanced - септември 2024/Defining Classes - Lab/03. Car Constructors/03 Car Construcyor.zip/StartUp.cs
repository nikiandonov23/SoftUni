﻿using System.Threading.Channels;

namespace CarManufacturer;

public class StartUp
{
    Car car0 = new Car();
    Car car1 = new Car("RENO", "MEGAN", 2021);
    Car car2 = new Car("Mercedes", "E-CLASS", 2020, 80, 5);
   

}