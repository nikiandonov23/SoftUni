﻿using CarManufacturer;

class Program
{
    static void Main(string[] args) // Това е входната точка на програмата
    {
    
    }
}