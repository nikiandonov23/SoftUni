﻿
using CarManufacturer;

Car newCar=new Car();
newCar.Make="Toyota";
newCar.Model="Yaris";
newCar.Year=2021;

Console.WriteLine($"Make: {newCar.Make}\nModel: {newCar.Model}\nYear {newCar.Year}");