﻿namespace P02_FootballBettingCommon;

public class ApplicationCommonConfiguration
{

    
        public const string ConnectionString =
            "Server=.;Database=FootballBookmakerSystem;Trusted_Connection=True;TrustServerCertificate=True";
    
    
}