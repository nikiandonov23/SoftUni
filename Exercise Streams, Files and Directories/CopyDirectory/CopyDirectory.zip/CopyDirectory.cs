﻿using System.IO;
using Microsoft.VisualBasic.FileIO;

namespace CopyDirectory
{
    using System;
    public class CopyDirectory
    {
        static void Main()
        {
            string inputPath =  @$"{Console.ReadLine()}";
            string outputPath = @$"{Console.ReadLine()}";

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            string[] files = Directory.GetFiles(inputPath);

            if (Directory.Exists(outputPath))
            {
                Directory.Delete(outputPath);
            }
            Directory.CreateDirectory(outputPath);

            foreach (var file in files)
            {
                string fileName=Path.GetFileName(file);
                string dirPath = Path.Combine(outputPath, fileName);

                File.Copy(file, dirPath);
            }

            
        }
    }
}
