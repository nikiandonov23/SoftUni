﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace LineNumbers
{
    using System;
    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] input = File.ReadAllLines(inputFilePath);
            string newInput = "";
            for (int i = 0; i < input.Length; i++)
            {

                List<int> currentOccurances = new List<int>();
                currentOccurances = LineAdd(input[i]);

                string formattedLine=$"Line: {i+1} {input[i]} ({currentOccurances[0]})({currentOccurances[1]})";
                newInput += formattedLine;


            }

            File.WriteAllText(outputFilePath, newInput);
        }
        private static List<int> LineAdd(string text)
        {
            int letters = 0;
            int punctoation = 0;

            for (int i = 0; i < text.Length; i++)
            {
                if (char.IsLetter(text[i]))
                {
                    letters++;
                }
                else if (char.IsPunctuation(text[i]))
                {
                    punctoation++;
                }
            }
            List<int> listOccurances = new List<int>();
            listOccurances.Add(letters);
            listOccurances.Add(punctoation);

            return listOccurances;
        }
    }
}
